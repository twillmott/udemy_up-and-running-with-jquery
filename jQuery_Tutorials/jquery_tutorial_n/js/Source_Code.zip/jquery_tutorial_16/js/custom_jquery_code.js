
// You'll need the below URLs while following along with the lecture for practice.
    // var root = "https://jsonplaceholder.typicode.com/posts/1";
    // var root = "https://jsonplaceholder.typicode.com/comments";
    // var url = "https://raw.githubusercontent.com/imtiazahmad007/resources/master/some_random_text.txt";
    // var url = "https://raw.githubusercontent.com/imtiazahmad007/resources/master/sample_table.html"

$(function(){

});
