
$(function(){
    $(":header").css({"border" :"1px solid red"});

});
