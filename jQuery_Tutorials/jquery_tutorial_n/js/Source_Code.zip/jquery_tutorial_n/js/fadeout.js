$("p").on('click', function(){
    $(this).fadeOut(1000);
});
